import React, { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';

// Register all Chart.js components
Chart.register(...registerables);

const ChartsAd = ({ 
  statuts = [], 
  top_entreprises = [], 
  signalements = [], 
  inscriptions = [] 
}) => {
  // Use refs to store chart instances
  const pieChartRef = useRef(null);
  const barChartRef = useRef(null);
  const areaChartRef = useRef(null);

  useEffect(() => {
    // Initialize charts when component mounts
    const statusData = {
      labels: statuts.map(item => item.status),
      datasets: [{
        data: statuts.map(item => item.nombre),
        backgroundColor: ['#ffc107', '#dc3545', '#28a745']
      }]
    };

    const barData = {
      labels: top_entreprises.map(item => item.nom_entreprise_fraud),
      datasets: [{
        label: 'Nombre de signalements',
        data: top_entreprises.map(item => item.total),
        backgroundColor: '#007bff'
      }]
    };

    const areaData = {
      labels: inscriptions.map(item => item.mois),
      datasets: [{
        label: 'Signalements mensuels',
        data: signalements.map(item => item.total),
        borderColor: 'rgba(255, 193, 7, 1)',
        backgroundColor: 'rgba(255, 193, 7, 0.2)',
        fill: true,
        tension: 0.4,
        borderWidth: 2
      }]
    };

    // Create charts
    if (pieChartRef.current) {
      pieChartRef.current = new Chart(
        document.getElementById('statusPieChart'), 
        {
          type: 'pie',
          data: statusData,
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'bottom'
              }
            }
          }
        }
      );
    }

    if (barChartRef.current) {
      barChartRef.current = new Chart(
        document.getElementById('barChart'), 
        {
          type: 'bar',
          data: barData,
          options: {
            responsive: true,
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        }
      );
    }

    if (areaChartRef.current) {
      areaChartRef.current = new Chart(
        document.getElementById('areaChart'), 
        {
          type: 'line',
          data: areaData,
          options: {
            responsive: true,
            scales: {
              y: { 
                beginAtZero: true 
              },
              x: { 
                grid: { 
                  color: 'rgba(0, 0, 0, 0.1)' 
                } 
              }
            }
          }
        }
      );
    }

    // Cleanup function
    return () => {
      // Destroy charts when component unmounts
      if (pieChartRef.current) {
        pieChartRef.current.destroy();
      }
      if (barChartRef.current) {
        barChartRef.current.destroy();
      }
      if (areaChartRef.current) {
        areaChartRef.current.destroy();
      }
    };
  }, [statuts, top_entreprises, signalements, inscriptions]);

  return (
    <div className="container-fluid px-4">
      <div className="card mb-4">
        <div className="card-body">
          <canvas id="areaChart" width="100%" height="20"></canvas>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-6">
          <div className="card mb-4">
            <div className="card-body">
              <canvas id="barChart" width="100%" height="50"></canvas>
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="card mb-4">
            <div className="card-body">
              <canvas id="statusPieChart" width="100%" height="50"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChartsAd;