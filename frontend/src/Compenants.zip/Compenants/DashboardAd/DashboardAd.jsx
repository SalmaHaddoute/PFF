import React from 'react';
import ChartsAd from '../ChartsAd/ChartsAd';

const DashboardAd = ({ 
    total_posts, 
    accepted_posts, 
    rejected_posts, 
    total_products,
    blacklist 
    }) => {
    return (
        <div className="row">
        {/* Card Box */}
        <div className="cardBox">
            <div className="card">
            <div>
                <div className="numbers">{total_posts}</div>
                <div className="cardName">Total réclamations</div>
            </div>
            <div className="iconBx">
                <ion-icon name="document-text-outline"></ion-icon>
            </div>
            </div>

            <div className="card">
            <div>
                <div className="numbers">{accepted_posts}</div>
                <div className="cardName">Réclamations Validée</div>
            </div>
            <div className="iconBx">
                <ion-icon name="checkmark-circle-outline"></ion-icon>
            </div>
            </div>
            
            <div className="card">
            <div>
                <div className="numbers">{rejected_posts}</div>
                <div className="cardName">Réclamations rejetées</div>
            </div>
            <div className="iconBx">
                <ion-icon name="close-circle-outline"></ion-icon>
            </div>
            </div>

            <div className="card">
            <div>
                <div className="numbers">{total_products}</div>
                <div className="cardName">Total Produits</div>
            </div>
            <div className="iconBx">
                <ion-icon name="cube-outline"></ion-icon>
            </div>
            </div>
        </div>

        {/* Charts Component */}
        <ChartsAd 
        statuts={statuts}
        top_entreprises={top_entreprises}
        signalements={signalements}
        inscriptions={inscriptions}
      />

        {/* Blacklisted Companies Table */}
        <div className="container-fluid px-4">
            <div className="card mb-4 border-0 shadow-sm">
            <div className="card-header bg-white border-0 d-flex justify-content-between align-items-center py-3">
                <h5 className="mb-0 fw-semibold">Entreprises Blacklistées</h5>
                <div className="d-flex align-items-center">
                <div className="me-3">
                    <select className="form-select form-select-sm" id="entries-select">
                    <option value="10">10 entrées par page</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    </select>
                </div>
                <div className="input-group input-group-sm" style={{width: '200px'}}>
                    <input type="text" className="form-control" placeholder="Rechercher..." />
                    <button className="btn btn-outline-secondary" type="button">
                    <i className="fas fa-search"></i>
                    </button>
                </div>
                </div>
            </div>
            <div className="card-body p-0">
                <div className="table-responsive">
                <table className="table table-hover mb-0">
                    <thead className="bg-light">
                    <tr>
                        <th className="py-3 px-4 text-uppercase small fw-semibold">ID</th>
                        <th className="py-3 px-4 text-uppercase small fw-semibold">Signalé par</th>
                        <th className="py-3 px-4 text-uppercase small fw-semibold">Entreprise frauduleuse</th>
                        <th className="py-3 px-4 text-uppercase small fw-semibold">Raison</th>
                        <th className="py-3 px-4 text-uppercase small fw-semibold">Preuve</th>
                        <th className="py-3 px-4 text-uppercase small fw-semibold">Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    {blacklist.slice(0, 4).map((entry) => (
                        <tr className="border-top" key={entry.id}>
                        <td className="py-3 px-4">{entry.id}</td>
                        <td className="py-3 px-4">{entry.nom_entreprise_post}</td>
                        <td className="py-3 px-4 fw-semibold">{entry.nom_entreprise_fraud}</td>
                        <td className="py-3 px-4 text-muted">{entry.raison}</td>
                        <td className="py-3 px-4">
                            {entry.preuve_file ? (
                            <span className="badge bg-light text-dark border">
                                <i className="fas fa-comment-alt me-1"></i> Message
                            </span>
                            ) : (
                            <span className="badge bg-light text-muted border">Aucune preuve</span>
                            )}
                        </td>
                        <td className="py-3 px-4 text-muted">
                            {new Date(entry.post_date).toLocaleDateString('fr-FR', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                            })}
                        </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
                </div>
                
                {/* Pagination */}
                <div className="d-flex justify-content-between align-items-center p-3 bg-light">
                <div className="text-muted small">
                    Affichage de 1 à 4 sur {blacklist.length} entrées
                </div>
                <div className="d-flex">
                    <button className="btn btn-sm btn-outline-secondary disabled me-2">
                    <i className="fas fa-chevron-left"></i>
                    </button>
                    <button className="btn btn-sm btn-outline-primary active me-2">1</button>
                    <button className="btn btn-sm btn-outline-secondary disabled">
                    <i className="fas fa-chevron-right"></i>
                    </button>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    );
};

export default DashboardAd;